<div class="form-group"> 
    <div class="col-sm-offset-4 col-sm-8">
      <button type="submit" class="btn btn-lg btn-danger" name="submit" value="Submit" onclick="return confirm('Are you sure?');">Submit</button>
    </div>
  </div>  
